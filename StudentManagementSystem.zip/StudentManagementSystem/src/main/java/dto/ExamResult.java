package dto;

public enum ExamResult {
    PAST,
    FAILED
}
