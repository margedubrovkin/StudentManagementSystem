package dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data()
@AllArgsConstructor()
@NoArgsConstructor()
@Entity(name = "students")

public class Student {

        @Id
        @GeneratedValue
        //@GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String firstName;
        private String lastName;
        private Integer age;
        @Enumerated(EnumType.STRING)
        @Column(name = "examresult")
        private ExamResult examResult;

        @OneToMany(mappedBy = "student")
        private List<Course> course;

        @ManyToOne
        private Teacher teacher;

        //because of lombok there's no need for getters/setters/tostring?


}