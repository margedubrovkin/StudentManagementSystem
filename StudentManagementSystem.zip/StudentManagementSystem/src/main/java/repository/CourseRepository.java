package repository;

public class CourseRepository {
}
