package repository;

public class TeacherRepository {
}
