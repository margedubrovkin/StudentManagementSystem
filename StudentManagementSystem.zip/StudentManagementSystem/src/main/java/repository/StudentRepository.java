package repository;

import dto.Course;
import dto.Student;
import dto.Teacher;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudentRepository {

    private static SessionFactory factory;

    public StudentRepository() {
        try {
            factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Student.class)
                    .addAnnotatedClass(Teacher.class)
                    .addAnnotatedClass(Course.class)
                    .buildSessionFactory();

        } catch (Exception exception) {
            System.out.println(exception.getClass() + ": " + exception.getMessage());
        }
    }
}

