package repository;

import dto.Course;
import dto.Student;
import dto.Teacher;

import java.util.ArrayList;
import java.util.List;

public class CentralRepository {
    private static List<Student> studentList = new ArrayList<>();
    private static List<Teacher> trainerList = new ArrayList<>();
    private static List<Course> courseList = new ArrayList<>();
}
