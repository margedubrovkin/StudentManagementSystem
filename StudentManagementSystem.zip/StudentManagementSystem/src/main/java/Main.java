import dto.Course;
import dto.ExamResult;
import dto.Student;
import dto.Teacher;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.management.Query;
import java.util.ArrayList;
import java.util.*;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .addAnnotatedClass(Teacher.class)
                .addAnnotatedClass(Course.class)
                .buildSessionFactory();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        //CREATE
        Student student1 = new Student();
        //student1.getId();
        student1.setFirstName("Juss");
        student1.setLastName("Jussike");
        student1.setAge(20);
        student1.setExamResult(ExamResult.PAST);

        session.persist(student1);
        System.out.println(student1);


        Student student2 = new Student();
        student2.setFirstName("Mickey");
        student2.setLastName("Mouse");
        student2.setAge(22);
        student2.setExamResult(ExamResult.FAILED);
        session.persist(student2);
        System.out.println(student2);

        Course course1 = new Course();
        course1.setCourseName("Math");
        session.persist(course1);
        System.out.println(course1);

        Course course2 = new Course();
        course2.setCourseName("IT");
        session.persist(course2);
        System.out.println(course2);

        Course course3 = new Course();
        course3.setCourseName("Biology");
        session.persist(course3);
        System.out.println(course3);

        //List<Course> courseList = new ArrayList<>();
        //courseList.add(0, course1);
        //courseList.add(1, course2);
        //courseList.add(2, course3);

        Teacher teacher1 = new Teacher();
        //teacher1.getId();
        teacher1.setFirstName("Miss");
        teacher1.setLastName("Marple");
        teacher1.setAge(70);
        teacher1.setCourse(course1);
        //teacher1.getStudent().add(student1);
        student1.setTeacher(teacher1);
        session.persist(teacher1);

        System.out.println(teacher1);

        Teacher teacher2 = new Teacher();
        //teacher2.getId();
        teacher2.setFirstName("Mister");
        teacher2.setLastName("Robinson");
        teacher2.setAge(80);
        teacher2.setCourse(course1);

        session.persist(teacher2);
        System.out.println(teacher2);

        //DELETE
        //session.delete(teacher2);

        /*Random r = new Random();

        for (int i = 1; i <= 10; i++) {
            Student s = new Student();
            s.setFirstName("FirstName" + i);
            s.setLastName("LastName" + i);
            s.setAge(r.nextInt(22));

            session.persist(s);
            System.out.println(s);*/
//READ
        Student foundStudent = session.get(Student.class, 1L);
        System.out.println(foundStudent);

        ArrayList<Teacher> query = (ArrayList<Teacher>) session.createQuery("FROM teachers where lastName = 'Marple'", Teacher.class).list();
        ArrayList<Student> query1 = (ArrayList<Student>) session.createQuery("from students where age=22", Student.class).list();

       System.out.println(query);
        System.out.println(query1);
        // }*/


            transaction.commit();
            session.close();


        }
    }



